from django.contrib import admin
from .models import GeneratedStory

# Register your models here.
admin.site.register(GeneratedStory)
