from django.contrib import admin
from .models import Lists

# Register your models here.
admin.site.register(Lists)

