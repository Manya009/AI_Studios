from django.apps import AppConfig


class ImagesappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imagesapp'
